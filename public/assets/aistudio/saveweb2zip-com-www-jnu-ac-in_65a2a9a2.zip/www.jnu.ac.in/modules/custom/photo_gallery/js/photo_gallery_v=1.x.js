jQuery(function() {
var selectedClass = "";
jQuery(".filter").click(function(){
selectedClass = jQuery(this).attr("data-rel");
jQuery("#gallery").fadeTo(100, 0.1);
jQuery("#gallery div").not("."+selectedClass).fadeOut().removeClass('animation');
setTimeout(function() {
jQuery("."+selectedClass).fadeIn().addClass('animation');
jQuery("#gallery").fadeTo(300, 1);
}, 300);
});
});