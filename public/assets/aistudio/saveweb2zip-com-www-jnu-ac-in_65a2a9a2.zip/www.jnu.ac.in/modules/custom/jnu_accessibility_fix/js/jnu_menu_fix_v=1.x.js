(function () {
  document.querySelectorAll('.we-mega-menu-li > a').forEach(function(el){
    el.setAttribute('tabindex', '0');
  });
})();