(function (Drupal, once) {

  Drupal.behaviors.jnuExternalLinkWarning = {
    attach: function (context) {

      // Detect language
      var path = window.location.pathname;
      var isHindi = path.startsWith('/hi');

      // Messages
      var messages = {
        en: {
          external: 'This will take you to an external website in a new tab. Do you want to continue?'
        },
        hi: {
          external: 'यह आपको एक बाहरी वेबसाइट पर ले जाएगा जो नए टैब में खुलेगी। क्या आप जारी रखना चाहते हैं?'
        }
      };

      once('external-link-warning', 'a[href]', context).forEach(function (link) {

        var rawHref = link.getAttribute('href');

        if (!rawHref) {
          return;
        }

        // Ignore special links
        if (
          rawHref.indexOf('mailto:') === 0 ||
          rawHref.indexOf('tel:') === 0 ||
          rawHref.indexOf('javascript:') === 0 ||
          rawHref.indexOf('#') === 0
        ) {
          return;
        }

        // Parse URL safely
        var parsedUrl;

        try {
          parsedUrl = new URL(rawHref, window.location.origin);
        } catch (e) {
          return;
        }

        // Compare hosts
        var currentHost = window.location.hostname.replace(/^www\./, '');
        var linkHost = parsedUrl.hostname.replace(/^www\./, '');

        var isExternal = currentHost !== linkHost;

        // External links only
        if (isExternal) {

          link.setAttribute('target', '_blank');
          link.setAttribute('rel', 'noopener noreferrer');

          link.addEventListener('click', function (e) {

            // Skip homepage custom popup links
            if (link.hasAttribute('data-jnu-popup-handled')) {
              return;
            }

            var message = isHindi
              ? messages.hi.external
              : messages.en.external;

            var confirmLeave = confirm(message);

            if (!confirmLeave) {
              e.preventDefault();
            }

          });

        }

      });

    }
  };

})(Drupal, once);