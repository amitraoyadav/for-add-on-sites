(function (Drupal) {

  Drupal.behaviors.jnuAccessibilityFix = {
    attach: function (context) {

      let pageTitle = document.title.replace(' | Jawaharlal Nehru University','').trim();

      /* -------------------------
         FIX IMAGE ALT TEXT
      ------------------------- */

      document.querySelectorAll('img').forEach(function(img){

        let alt = img.getAttribute('alt');

        if(!alt || alt.trim() === ''){

          let filename = img.src.split('/').pop();
          filename = filename.replace(/\.[^/.]+$/, "");
          filename = filename.replace(/[-_]/g,' ');
          filename = filename.replace(/[0-9]/g,'');

          filename = filename.trim();

          if(filename.length > 3){
            img.setAttribute('alt', filename);
          } else if(pageTitle){
            img.setAttribute('alt', pageTitle + ' image');
          } else {
            img.setAttribute('alt','Jawaharlal Nehru University image');
          }

        }

      });


      /* -------------------------
         FIX ICON ACCESSIBILITY
      ------------------------- */

      document.querySelectorAll('i.fa, i.icon').forEach(function(icon){

        if(!icon.hasAttribute('aria-hidden')){
          icon.setAttribute('aria-hidden','true');
        }

      });


      /* -------------------------
         FIX ICON BUTTON LABELS
      ------------------------- */

      document.querySelectorAll('button').forEach(function(btn){

        if(!btn.getAttribute('aria-label')){

          let text = btn.innerText.trim();

          if(text.length){
            btn.setAttribute('aria-label', text);
          }

        }

      });


      /* -------------------------
         FIX LINK ICON LABELS
      ------------------------- */

      document.querySelectorAll('a').forEach(function(link){

        if(!link.getAttribute('aria-label')){

          let text = link.innerText.trim();

          if(text.length){
            link.setAttribute('aria-label', text);
          }

        }

      });

    }
  };

})(Drupal);