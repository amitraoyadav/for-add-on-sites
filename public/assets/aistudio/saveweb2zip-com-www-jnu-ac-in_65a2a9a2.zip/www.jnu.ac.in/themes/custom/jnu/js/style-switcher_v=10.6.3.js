function setCookie(cname, cvalue, exdays) {
	var d = new Date();
	d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
	var expires = "expires=" + d.toUTCString();
	document.cookie = cname + "=" + cvalue + "; " + expires + "; path=/";
}

function getCookie(cname) {
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for (var i = 0; i < ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0) === ' ') {
			c = c.substring(1);
		}
		if (c.indexOf(name) === 0) {
			return c.substring(name.length, c.length);
		}
	}
	return "";
}
jQuery(document).ready(function () {

	if(getCookie("bgcolor") !== ""){
		jQuery('body').addClass(getCookie("bgcolor"));
	}

	jQuery('#high_contrast').on('click', function () {
		if(jQuery('body').hasClass("dark")){
			jQuery('body').removeClass('dark');
			setCookie("bgcolor", "default", 7);
		}else{
			jQuery('body').addClass("dark").removeClass("blue").removeClass("orange").removeClass("green").removeClass('grey');
			setCookie("bgcolor", "dark", 7);
		}
	});

	jQuery('#blue-button').on('click', function () {
		if(jQuery('body').hasClass("blue")){
			jQuery('body').removeClass('blue');
			setCookie("bgcolor", "default", 7);
		}else{
			jQuery('body').addClass("blue").removeClass("dark").removeClass("orange").removeClass("green").removeClass('grey');
			setCookie("bgcolor", "blue", 7);
		}
	});

	jQuery('#green-button').on('click', function () {
		if(jQuery('body').hasClass("green")){
			jQuery('body').removeClass('green');
			setCookie("bgcolor", "default", 7);
		}else{
			jQuery('body').addClass("green").removeClass("dark").removeClass("blue").removeClass("orange").removeClass('grey');
			setCookie("bgcolor", "green", 7);
		}
	});

	jQuery('#orange-button').on('click', function () {
		if(jQuery('body').hasClass("orange")){
			jQuery('body').removeClass('orange');
			setCookie("bgcolor", "default", 7);
		}else{
			jQuery('body').addClass("orange").removeClass("dark").removeClass("blue").removeClass("green").removeClass('grey');
			setCookie("bgcolor", "orange", 7);
		}
	});

	jQuery('#grey-button').on('click', function () {
		if(jQuery('body').hasClass("grey")){
			jQuery('body').removeClass('grey');
			setCookie("bgcolor", "default", 7);
		}else{
			jQuery('body').addClass("grey").removeClass("dark").removeClass("blue").removeClass("green").removeClass('orange');
			setCookie("bgcolor", "grey", 7);
		}
	});
});