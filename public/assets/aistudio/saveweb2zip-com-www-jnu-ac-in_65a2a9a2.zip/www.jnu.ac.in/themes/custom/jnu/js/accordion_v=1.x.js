(function ($, Drupal, once) {
  // CKEditor Accordion
  function attachCkeditorAccordion(context) {
    console.log("📌 CKEditor Accordion attach called");

    once('ckeditor-accordion', 'dl.ckeditor-accordion dt', context).forEach(function (dt) {
      const $dt = $(dt);

      if (!$dt.find('.accordion-toggle-icon').length) {
        $dt.prepend('<span class="accordion-toggle-icon">▶</span> ');
      }

      $dt.on('click', function () {
        var $accordion = $(this).closest('dl.ckeditor-accordion');
        $accordion.find('dt').removeClass('open');
        $accordion.find('dd').slideUp(200);
        $accordion.find('.accordion-toggle-icon').text('▶');

        if (!$(this).next('dd').is(':visible')) {
          $(this).addClass('open');
          $(this).next('dd').slideDown(200);
          $(this).find('.accordion-toggle-icon').text('▼');
        }
      });
    });

    $('dl.ckeditor-accordion dd', context).hide();
  }

  // Career Page Accordion
  function attachCareerAccordion(context) {
    console.log("📌 Career Accordion attach called");

    once('career-accordion', '.career-heading', context).forEach(function (heading) {
      const $heading = $(heading);
      $heading.css('cursor', 'pointer');

      $heading.on('click', function () {
        const $this = $(this);
        const $content = $this.next();

        $content.slideToggle(300);
        $this.toggleClass('open');
        $('.career-heading').not($this).removeClass('open').next().slideUp(300);
      });
    });
  }

  Drupal.behaviors.ckeditorAccordion = {
    attach: function (context, settings) {
      attachCkeditorAccordion(context);

      // ✅ Corrected line
      once('accordion-rebind', '.quicktabs-tabs li a', context).forEach(function (el) {
        $(el).on('click', function () {
          setTimeout(function () {
            attachCkeditorAccordion(document);
          }, 300);
        });
      });
    }
  };

  Drupal.behaviors.careerAccordion = {
    attach: function (context, settings) {
      attachCareerAccordion(context);
    }
  };

})(jQuery, Drupal, once);