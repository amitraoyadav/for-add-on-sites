jQuery(document).ready(function(){


	jQuery(".faculty-search-wrapper h3").click(function(){
		jQuery(this).toggleClass('active');
		jQuery(this).next().slideToggle();
		jQuery(this).next().next(".faculty-search-list").animate({height: 'toggle'})
	});

	var classes = jQuery('body').attr('class').split(' ');
	var newClass = '';
	for(var i = 0; i < classes.length; i++) {
	  newClass += classes[i].replace("/", "-") + " ";
	}
	 
	jQuery("body").removeClass();
	jQuery("body").addClass(newClass);
	jQuery('.view-display-id-page_6 h3').addClass('career-heading');
	jQuery('.faculty-search-wrapper h3').addClass('fac-title');
	var item = jQuery(".faculty-search-wrapper" ).each(function(i) {
	jQuery(this).addClass("item-"+i);
	})
	var i;
	var len  = item.length;
	for (i = 0; i < len; i++) {
	var len2 = jQuery('.faculty-search-wrapper.item-'+i+' ul li').length;
	console.log(len2);
	jQuery('.faculty-search-wrapper.item-'+i+' h3').append(' ('+len2+')');
	jQuery('.faculty-search-wrapper.item-'+i+' h3').after('<p class="fac-num">Number of Faculty: '+len2+ '</p>');
	}
	
	setTimeout(function(){
		jQuery('nav.main ul li:nth-child(1)').click( function() {
			jQuery("#quicktabs-front_page_qui ul li:nth-child(2)").addClass("active");
			jQuery("#quicktabs-tabpage-front_page_qui-1").removeClass("quicktabs-hide");
			jQuery("#quicktabs-front_page_qui ul li:nth-child(4)").removeClass("active");
			jQuery("#quicktabs-tabpage-front_page_qui-3").addClass("quicktabs-hide");
			jQuery("#quicktabs-front_page_qui ul li:nth-child(1)").removeClass("active");
			jQuery("#quicktabs-tabpage-front_page_qui-0").addClass("quicktabs-hide");
		} );
	
		jQuery('.stellarnav ul.we-mega-menu-ul.nav.nav-tabs > li:nth-child(3) .we-mega-menu-submenu .nav-tabs.subul li:nth-child(1)').click( function() {
			jQuery("#quicktabs-front_page_qui ul li:nth-child(2)").removeClass("active");
			jQuery("#quicktabs-tabpage-front_page_qui-1").addClass("quicktabs-hide");
			jQuery("#quicktabs-front_page_qui ul li:nth-child(4)").addClass("active");
			jQuery("#quicktabs-tabpage-front_page_qui-3").removeClass("quicktabs-hide");
			jQuery("#quicktabs-front_page_qui ul li:nth-child(1)").removeClass("active");
			jQuery("#quicktabs-tabpage-front_page_qui-0").addClass("quicktabs-hide");
		} );
		}, 500);

// Tender and Notice
	var currURL= window.location.href;
	currURL =  currURL.split('?')[0];
	console.log(currURL);
	window.history.pushState("","", currURL);

	jQuery("<div class='responsive-table'>").insertAfter("</table>")
    //jQuery(".mainnav nav > ul > li:first > a").replaceWith("<i class='fa fa-home' style='font-size:24px;'></i>");  
    jQuery('.views_slideshow_controls_text_pause .views-slideshow-controls-text-pause-processed .views-slideshow-controls-text-status-pause > a').replaceWith('hi');
    jQuery(".views-slideshow-controls-text-next-processed > a").replaceWith("<i class='fa fa-chevron-right'></i>");
    jQuery(".views-slideshow-controls-text-previous-processed > a").replaceWith("<i class='fa fa-chevron-left'></i>");
    jQuery('#toggleSearch').on('click',function(){
      jQuery('.ico-site-search .search-drop').toggleClass('search-show');
    });
    jQuery("#search-block-form .form-search").attr("placeholder", "search");

    // Whats new

    jQuery('.wts-new').on({
          'cycle': console.log.bind(console, 'wts-new', 'cycle'),
          'pause': console.log.bind(console, 'wts-new', 'pause'),
          'resume': console.log.bind(console, 'wts-new', 'resume'),
          'finish': console.log.bind(console, 'wts-new', 'finish')
            });
    jQuery('.wts-new').simplemarquee({
          direction: 'top',
          speed:50,
          cycles: 100,
          delayBetweenCycles: 100 
          });
    
    // Tender and Notice

    jQuery('.homesec2sec3bxcntnt').on({
          'cycle': console.log.bind(console, 'homesec2sec3bxcntnt', 'cycle'),
          'pause': console.log.bind(console, 'homesec2sec3bxcntnt', 'pause'),
          'resume': console.log.bind(console, 'homesec2sec3bxcntnt', 'resume'),
          'finish': console.log.bind(console, 'homesec2sec3bxcntnt', 'finish')
            });
    jQuery('.homesec2sec3bxcntnt').simplemarquee({
          direction: 'top',
          speed:50,
          cycles: 100,
          delayBetweenCycles: 100
          });

    //  homeslider start
	var owl = jQuery('.homeslider.owl-carousel');
              owl.owlCarousel({
                items: 1,
				nav: true,
                loop: true,
                margin: 0,
				smartSpeed: 1000,
                autoplay: true,
                autoplayTimeout: 2000,
                autoplayHoverPause: true
              });
              jQuery('.play').on('click', function() {
				owl.trigger('play.owl.autoplay', [2000]);
				jQuery('.homeslidersec .play').css("display", "none");
				jQuery('.homeslidersec .stop').css("display", "inline-block");
				})
              jQuery('.stop').on('click', function() {
				owl.trigger('stop.owl.autoplay')
				jQuery('.homeslidersec .play').css("display", "inline-block");
				jQuery('.homeslidersec .stop').css("display", "none");
				
     });
	 //  homeslider over
	 //  clientowl start
	
		
		var clintowl = jQuery('.homeclientslider.owl-carousel');
        clintowl.owlCarousel({
     	loop: true,
		margin: 10,
		smartSpeed: 1000,
		autoplay: true,
		autoplayTimeout: 2000,
		autoplayHoverPause: true,
		responsive:{
        		0:{
					items:1
				},
				770:{
					items:3
				},
				991:{
					items:5
				},
				1199:{
					items:7
				}
			}
		});
		
	 //  clientowl over
	 //  what new vertical scroller start
		/*jQuery('.whatnewbxcntnt').bxSlider({
    		mode: 'vertical',
    		minSlides: 1,
    		slideMargin: 0,
    		auto:true,
    		moveSlides:1,
    		controls:false,
    		pager:false,
			speed:2000,
			autoHover:true,
			autoDelay:1000
  		});*/
     //  what new vertical scroller over
	 //  tender and notice scroller vertical scroller start
		/*jQuery('.homesec2sec3bxcntnt').bxSlider({
    		mode: 'vertical',
    		minSlides: 1,
    		slideMargin: 0,
    		auto:true,
    		moveSlides:1,
    		controls:false,
    		pager:false,
			speed:2000,
			autoHover:true,
			autoDelay:1000
  		});*/
     //  tender and notice scroller vertical scroller over
	 //  important circular scroller vertical scroller start
		jQuery('.importantcirculatbx1cntntbx ul').bxSlider({
    		mode: 'vertical',
    		minSlides: 5,
    		slideMargin: 0,
    		auto:true,
    		moveSlides:1,
    		controls:false,
    		pager:false,
			speed:1000,
			autoHover:true,
			autoDelay:50
  		});
     //  important circular scroller vertical scroller over

	if (screen.width <= 991)
	{
		var htm1 = jQuery('.topleftnav .gov-india').html();
		jQuery('.topleftnav .gov-india').empty();
		jQuery('.region-primary-menu .mainnav nav > ul').append('<li class="gov-india">'+htm1+'</li>');
		
		var htmli11 = jQuery('.topstriprightnav > li:nth-child(1)').html();
		var htmli12 = jQuery('.topstriprightnav > li:nth-child(2)').html();
		var htmli13 = jQuery('.topstriprightnav > li:nth-child(3)').html();
		
		var htmli14 = jQuery('.region-external-links .view-filters').html();
		
		
		jQuery('.topstriprightnav > li:nth-child(1),.topstriprightnav > li:nth-child(2),.topstriprightnav > li:nth-child(3),.region-external-links .view-filters').empty();
		jQuery('.region-primary-menu .mainnav nav > ul').append('<li>'+htmli11+'</li>');
		jQuery('.region-primary-menu .mainnav nav > ul').append('<li>'+htmli12+'</li>');
		jQuery('.region-primary-menu .mainnav nav > ul').append('<li>'+htmli13+'</li>');
		jQuery('.region-primary-menu .mainnav nav > ul').append('<li class="lstslctbx">'+htmli14+'</li>');
	}
	
	jQuery('li.ico-accessibility a,li.ico-social a,li.hindi.cmf_lan a').click(function(e) {
     	jQuery(this).next('ul').slideToggle();
		jQuery(this).next('ul').classToggle('active');
		
    });
	//  main nav over
	
	 
	 
});

jQuery(document).ready(function(){
	setTimeout(function() {
	jQuery(".hometab4half ul li:has(dl)").addClass('lidrpdn');
	}, 3000);
});

jQuery(document).ready(function(){
  jQuery(".accordian_tender_title").click(function(){
    jQuery(this).next(".accordian_tender_contents").animate({height: 'toggle'});
  });
});

jQuery(document).ready(function(){
  jQuery(window).scroll(function(){
    if (jQuery(window).scrollTop() > 100){
      jQuery('header').addClass( "fixed-header");
    } else {
      jQuery('header').removeClass("fixed-header");
    }
  });
});

function searchfun(e){
	e.parentElement.previousElementSibling.classList.toggle("active");
	//var x = e.previousElementSibling;
	//console.log(x);
	//x.classList.toggle("active");
}

//redirect to out site Dated: 24-01-2022
jQuery('.faculty-web-link a') .click(function () {
	return confirm('By clicking OK button you are agree to see this page which is updated by faculty!!!');
});

//redirect to outersite Dated: 23-03-2021 Rahul Gupta
//jQuery('.faculty-web-link a') .click(function () {
//	return confirm('By clicking OK button you are agree to see this page which is updated by faculty!\n ??? ??? ?? ????? ???? ?? ?? ????? ?? ????? ?? ??? ???? ??? ?? ????? ?????? ?????? ???? ??? ???');
//});

var searchNode = document.createElement('div');
searchNode.className = 'searchcustombtn';
var searchtxt = '';
searchtxt += '<i onclick="searchfun(this)" class="fas fa-search"></i>';
searchNode.innerHTML = searchtxt;
document.getElementsByClassName("searchlt")[0].appendChild(searchNode);


///scns-faculty page issue
document.addEventListener("DOMContentLoaded", function() {
    if (document.body.classList.contains('page-node-159892990')) {
        const container = document.querySelector('.region-content');
        if (container) {
            const ids = [
                'block-jnu-views-block-sbt-faculties-block-1',
                'block-jnu-views-block-sbt-faculties-block-2',
                'block-jnu-views-block-sbt-faculties-block-3'
            ];

            ids.forEach(id => {
                const block = document.getElementById(id);
                if (block) {
                    container.appendChild(block);
                }
            });
        }
    }
});


document.addEventListener("DOMContentLoaded", function() {
    const toggle = document.querySelector('.navbar-toggle');
    const menu = document.querySelector('.mobile-main-menu');

    if (toggle && menu) {
        function toggleMenu(e) {
            e.preventDefault();
            toggle.classList.toggle('collapsed');
            menu.classList.toggle('open');
        }

        // Attach both click and touchstart for iOS
        toggle.addEventListener('click', toggleMenu, false);
        toggle.addEventListener('touchstart', toggleMenu, false);
    }
});

/*
document.querySelectorAll('a[href*=".pdf"]').forEach(function(link){
  link.insertAdjacentHTML("beforeend", ' <i class="fa fa-file-pdf-o" aria-hidden="true" style="color:red;display: inline;float: none;"></i>');
});

*/
//For research page slider 
document.addEventListener("DOMContentLoaded", function () {

  function fixFractionSliderAccessibility() {

    /* Fix prev button */

    document.querySelectorAll("a.prev").forEach(function(el){

      if(el.innerHTML.trim() === ""){
        el.innerHTML = '<span class="visually-hidden">Previous slide</span>';
      }

      el.setAttribute("aria-label","Previous slide");

    });

    /* Fix next button */

    document.querySelectorAll("a.next").forEach(function(el){

      if(el.innerHTML.trim() === ""){
        el.innerHTML = '<span class="visually-hidden">Next slide</span>';
      }

      el.setAttribute("aria-label","Next slide");

    });

    /* Fix pager dots */

    document.querySelectorAll(".fs-pager-wrapper a").forEach(function(el,index){

      if(el.innerHTML.trim() === ""){
        el.innerHTML = '<span class="visually-hidden">Slide '+(index+1)+'</span>';
      }

      el.setAttribute("aria-label","Go to slide "+(index+1));

    });

  }

  /* run immediately */
  fixFractionSliderAccessibility();

  /* run again after slider loads */
  setTimeout(fixFractionSliderAccessibility,1000);
  setTimeout(fixFractionSliderAccessibility,2000);

}); 


//For faculty books listing
(function ($, Drupal) {

  Drupal.behaviors.fixColorboxAccessibility = {
    attach: function (context, settings) {

      function applyFix() {

        const buttons = {
          cboxPrevious: "Previous image",
          cboxNext: "Next image",
          cboxSlideshow: "Start slideshow"
        };

        Object.keys(buttons).forEach(function(id) {

          const btn = document.getElementById(id);

          if (btn) {
            btn.setAttribute("aria-label", buttons[id]);

            if (btn.innerHTML.trim() === "") {
              btn.innerHTML = '<span class="visually-hidden">' + buttons[id] + '</span>';
            }
          }

        });

      }

      /* Run immediately */
      applyFix();

      /* Run again after Colorbox opens */
      $(document).on('cbox_complete', function () {
        applyFix();
      });

    }
  };

})(jQuery, Drupal); 

/*Mobile Page load configuration issue*/


/*Contact Page autocomplete attribute add script*/
(function (Drupal, once) {

  Drupal.behaviors.jnuContactFormEnhancement = {
    attach: function (context) {

      once('jnu-contact-form-enhancement', '#contact-message-feedback-form', context).forEach(function (form) {

        var nameField = form.querySelector('#edit-name');
        var emailField = form.querySelector('#edit-mail');
        var subjectField = form.querySelector('#edit-subject-0-value');
        var messageField = form.querySelector('#edit-message-0-value');

        /* =========================
           LANGUAGE DETECTION
        ========================= */
        var isHindi = window.location.pathname.startsWith('/hi');

        var msg = {

          /* Placeholders */
          namePH: isHindi ? 'अपना नाम दर्ज करें' : 'Enter your name',
          emailPH: isHindi ? 'अपना ईमेल पता दर्ज करें' : 'Enter your email address',
          subjectPH: isHindi ? 'विषय दर्ज करें' : 'Enter subject',
          messagePH: isHindi ? 'अपना संदेश दर्ज करें' : 'Enter your message',

          /* Errors */
          nameRequired: isHindi ? 'कृपया अपना नाम दर्ज करें।' : 'Please enter your name.',
          nameInvalid: isHindi ? 'कृपया मान्य नाम दर्ज करें।' : 'Please enter a valid name. Only characters and space are allowed.',
          nameMax: isHindi ? 'नाम 20 अक्षरों से अधिक नहीं होना चाहिए।' : 'Name must not exceed 20 characters.',

          emailRequired: isHindi ? 'कृपया अपना ईमेल पता दर्ज करें।' : 'Please enter your email address.',
          emailInvalid: isHindi ? 'कृपया मान्य ईमेल पता दर्ज करें।' : 'Please enter a valid email address.',
          emailMax: isHindi ? 'ईमेल 50 अक्षरों से अधिक नहीं होना चाहिए।' : 'Email must not exceed 50 characters.',

          subjectRequired: isHindi ? 'कृपया विषय दर्ज करें।' : 'Please enter the subject.',
          subjectMin: isHindi ? 'विषय कम से कम 3 अक्षरों का होना चाहिए।' : 'Subject must be at least 3 characters long.',
          subjectMax: isHindi ? 'विषय 50 अक्षरों से अधिक नहीं होना चाहिए।' : 'Subject must not exceed 50 characters.',

          messageRequired: isHindi ? 'कृपया अपना संदेश दर्ज करें।' : 'Please enter your message.',
          messageMin: isHindi ? 'संदेश कम से कम 10 अक्षरों का होना चाहिए।' : 'Message must be at least 10 characters long.'
        };

        /* =========================
           PLACEHOLDER + ATTRIBUTES
        ========================= */
        if (nameField) {
          nameField.setAttribute('autocomplete', 'name');
          nameField.setAttribute('maxlength', '20');
          nameField.setAttribute('placeholder', msg.namePH);
        }

        if (emailField) {
          emailField.setAttribute('autocomplete', 'email');
          emailField.setAttribute('maxlength', '50');
          emailField.setAttribute('placeholder', msg.emailPH);
        }

        if (subjectField) {
          subjectField.setAttribute('autocomplete', 'off');
          subjectField.setAttribute('maxlength', '50');
          subjectField.setAttribute('placeholder', msg.subjectPH);
        }

        if (messageField) {
          messageField.setAttribute('autocomplete', 'off');
          messageField.setAttribute('placeholder', msg.messagePH);
        }

        /* =========================
           COMMON FUNCTIONS
        ========================= */
        function getFieldWrapper(field) {
          return field.closest('.js-form-item') || field.closest('.form-item') || field.parentNode;
        }

        function removeError(field) {
          if (!field) return;

          field.classList.remove('error');
          field.style.border = '';

          var wrapper = getFieldWrapper(field);
          if (!wrapper) return;

          wrapper.querySelectorAll('.custom-error-message').forEach(function (err) {
            err.remove();
          });
        }

        function showError(field, message) {
          if (!field) return false;

          var wrapper = getFieldWrapper(field);
          if (!wrapper) return false;

          removeError(field);

          field.classList.add('error');
          field.style.border = '1px solid red';

          var error = document.createElement('div');
          error.className = 'custom-error-message';
          error.style.color = 'red';
          error.style.fontSize = '13px';
          error.style.marginTop = '5px';
          error.textContent = message;

          wrapper.appendChild(error);

          return false;
        }

        /* =========================
           VALIDATIONS
        ========================= */

        function validateName() {
          if (!nameField) return true;

          var value = nameField.value.trim();
          var nameRegex = /^[A-Za-z\s.'-]{2,20}$/;

          removeError(nameField);

          if (value === '') return showError(nameField, msg.nameRequired);
          if (!nameRegex.test(value)) return showError(nameField, msg.nameInvalid);
          if (value.length > 20) return showError(nameField, msg.nameMax);

          return true;
        }

        function validateEmail() {
          if (!emailField) return true;

          var value = emailField.value.trim();
          var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

          removeError(emailField);

          if (value === '') return showError(emailField, msg.emailRequired);
          if (!emailRegex.test(value)) return showError(emailField, msg.emailInvalid);
          if (value.length > 50) return showError(emailField, msg.emailMax);

          return true;
        }

        function validateSubject() {
          if (!subjectField) return true;

          var value = subjectField.value.trim();

          removeError(subjectField);

          if (value === '') return showError(subjectField, msg.subjectRequired);
          if (value.length < 3) return showError(subjectField, msg.subjectMin);
          if (value.length > 50) return showError(subjectField, msg.subjectMax);

          return true;
        }

        function validateMessage() {
          if (!messageField) return true;

          var value = messageField.value.trim();

          removeError(messageField);

          if (value === '') return showError(messageField, msg.messageRequired);
          if (value.length < 10) return showError(messageField, msg.messageMin);

          return true;
        }

        /* =========================
           EVENTS
        ========================= */

        if (nameField) {
          nameField.addEventListener('blur', validateName);
          nameField.addEventListener('input', () => nameField.classList.contains('error') && validateName());
        }

        if (emailField) {
          emailField.addEventListener('blur', validateEmail);
          emailField.addEventListener('input', () => emailField.classList.contains('error') && validateEmail());
        }

        if (subjectField) {
          subjectField.addEventListener('blur', validateSubject);
          subjectField.addEventListener('input', () => subjectField.classList.contains('error') && validateSubject());
        }

        if (messageField) {
          messageField.addEventListener('blur', validateMessage);
          messageField.addEventListener('input', () => messageField.classList.contains('error') && validateMessage());
        }

        form.addEventListener('submit', function (e) {

          var isValid =
            validateName() &&
            validateEmail() &&
            validateSubject() &&
            validateMessage();

          if (!isValid) {
            e.preventDefault();

            var firstErrorField = form.querySelector('.error');
            if (firstErrorField) firstErrorField.focus();
          }

        });

      });

    }
  };

})(Drupal, once);

/***anchor tag should be underline within content region****/

(function (Drupal, once) {
  Drupal.behaviors.jnuUnderlineContentLinks = {
    attach: function (context) {

      once(
        'jnu-underline-content-links',
        'main a, [role="main"] a, .dialog-off-canvas-main-canvas a',
        context
      ).forEach(function (link) {

        if (
          link.closest('header, footer, nav, .header, .footer, .nav, .navbar, .menu, .tabs, .breadcrumb, .pager, .btn, .button, .region-primary-menu, .region-header, .region-footer')
        ) {
          return;
        }

        link.style.setProperty('text-decoration', 'underline', 'important');
        link.style.setProperty('text-underline-offset', '2px', 'important');
      });

    }
  };
})(Drupal, once); 

/**Home page slider play and pause buttonn with right & left arrow**/
/*
(function ($, Drupal, once) {

  Drupal.behaviors.jnuSliderAccessibleControls = {
    attach: function (context) {

      once('jnu-slider-accessible-controls', 'body', context).forEach(function () {

        var $slider = $('#views_slideshow_cycle_teaser_section_home_slideshow_-block_1');
        var $main = $('#views_slideshow_cycle_main_home_slideshow_-block_1');
        var $pauseWrap = $('#views_slideshow_controls_text_pause_home_slideshow_-block_1');
        var $pauseLink = $('#views_slideshow_controls_text_pause_home_slideshow_-block_1 a');
        var $prev = $('#views_slideshow_controls_text_previous_home_slideshow_-block_1');
        var $next = $('#views_slideshow_controls_text_next_home_slideshow_-block_1');

        if (!$slider.length || !$main.length || !$pauseLink.length) {
          return;
        }

        $main.css('position', 'relative');

        // Hide only original pause text
        $pauseWrap.css({
          position: 'absolute',
          left: '-9999px',
          width: '1px',
          height: '1px',
          overflow: 'hidden'
        });

        // Create custom play/pause button once
        if (!$('#jnu-slider-toggle').length) {
          $main.append('<button id="jnu-slider-toggle" type="button">Pause</button>');
        }

        var $button = $('#jnu-slider-toggle');

        // Proper button style
        $button.css({
          position: 'absolute',
          right: '20px',
          bottom: '20px',
          top: 'auto',
          left: 'auto',
          width: 'auto',
          height: 'auto',
          display: 'inline-block',
          visibility: 'visible',
          opacity: '1',
          zIndex: '9999',
          background: '#000',
          color: '#fff',
          border: '1px solid #fff',
          padding: '10px 16px',
          cursor: 'pointer',
          fontSize: '14px',
          lineHeight: '1.2',
          borderRadius: '4px'
        });

        // Show and style prev/next properly
        $prev.css({
		  position: 'absolute',
		  left: '20px',
		  top: '50%',
		  transform: 'translateY(-50%)',
		  zIndex: '9999',
		  display: 'flex',
		  alignItems: 'center',
		  justifyContent: 'center',
		  width: '48px',
		  height: '48px',
		  background: '#fff',
		  color: '#fff',
		  border: 'none',
		  borderRadius: '0',
		  cursor: 'pointer',
		  padding: '0',
		  fontSize: '0'
		}).html('<span aria-hidden="true" style="font-size:60px; line-height:1; font-weight:400;opacity:1;color:#000;text-align:center;height:75px !important;text-decoration:none;">&#8249;</span>');


        $next.css({
		  position: 'absolute',
		  right: '20px',
		  top: '50%',
		  transform: 'translateY(-50%)',
		  zIndex: '9999',
		  display: 'flex',
		  alignItems: 'center',
		  justifyContent: 'center',
		  width: '48px',
		  height: '48px',
		  background: '#fff',
		  color: '#fff',
		  border: 'none',
		  borderRadius: '0',
		  cursor: 'pointer',
		  padding: '0',
		  fontSize: '0'
		}).html('<span aria-hidden="true" style="font-size:60px; line-height:1; font-weight:400;opacity:1;color:#000;text-align:center;height:75px !important;text-decoration:none;">&#8250;</span>');

        $prev.attr('role', 'button').attr('aria-label', 'Previous slide').attr('tabindex', '0');
        $next.attr('role', 'button').attr('aria-label', 'Next slide').attr('tabindex', '0');

        // State
        var isPaused = false;

        function stopSlider() {
          if ($.fn.cycle) {
            $slider.cycle('pause');
          }
          isPaused = true;
          syncButton();
        }

        function startSlider() {
          if ($.fn.cycle) {
            $slider.cycle('resume');
          }
          isPaused = false;
          syncButton();
        }

        function syncButton() {
          if (isPaused) {
            $button.text('Play');
            $button.attr('aria-label', 'Play slideshow');
            $button.attr('aria-pressed', 'true');
          } else {
            $button.text('Pause');
            $button.attr('aria-label', 'Pause slideshow');
            $button.attr('aria-pressed', 'false');
          }
        }

        // Default state = running
        isPaused = false;
        syncButton();

        $button.off('click.jnuToggle').on('click.jnuToggle', function (e) {
          e.preventDefault();
          e.stopPropagation();

          if (isPaused) {
            startSlider();
          } else {
            stopSlider();
          }
        });

        $prev.off('click.jnuPrev').on('click.jnuPrev', function (e) {
          e.preventDefault();
          e.stopPropagation();
          if ($.fn.cycle) {
            $slider.cycle('prev');
          }
        });

        $next.off('click.jnuNext').on('click.jnuNext', function (e) {
          e.preventDefault();
          e.stopPropagation();
          if ($.fn.cycle) {
            $slider.cycle('next');
          }
        });

        $prev.off('keydown.jnuPrev').on('keydown.jnuPrev', function (e) {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            $(this).trigger('click');
          }
        });

        $next.off('keydown.jnuNext').on('keydown.jnuNext', function (e) {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            $(this).trigger('click');
          }
        });

      });

    }
  };

})(jQuery, Drupal, once);
*/

/**Home page slider play and pause buttonn with right & left arrow**/

(function ($, Drupal, once) {

  // Inject visually-hidden CSS for accessibility labels
  if (!$('#jnu-accessibility-styles').length) {
    $('<style id="jnu-accessibility-styles">')
      .prop('type', 'text/css')
      .html('.visually-hidden { position: absolute !important; width: 1px !important; height: 1px !important; padding: 0 !important; margin: -1px !important; overflow: hidden !important; clip: rect(0, 0, 0, 0) !important; white-space: nowrap !important; border: 0 !important; }')
      .appendTo('head');
  }

  /**
   * Unified Play/Pause control for JNU Sliders (Views Slideshow & Fraction Slider).
   */
  Drupal.behaviors.jnuSliderPlayPause = {
    attach: function (context) {
      // 1. Views Slideshow (Generic support for all instances)
      var vsSelector = '.views_slideshow_main';
      
      once('jnu-views-slideshow-control', vsSelector, context).forEach(function (slider) {
        var $slider = $(slider);
        
        // Skip if slider has only one slide
        var slideCount = $slider.find('.views_slideshow_cycle_slide').length;
        if (slideCount <= 1) return;

        // Find the most appropriate container to append the button
        var $container = $slider.closest('.views-slideshow-cycle-main-frame-wrapper').length ? 
                         $slider.closest('.views-slideshow-cycle-main-frame-wrapper') : 
                         ($slider.closest('.skin-default').length ? $slider.closest('.skin-default') : $slider.parent());

        // Extract slideshow ID for Drupal.viewsSlideshow.action
        var slideshowID = $slider.attr('id').replace('views_slideshow_cycle_main_', '');

        createPlayPauseButton($container, function (isPaused) {
          // Use the official Drupal Views Slideshow action system for maximum reliability
          if (window.Drupal && Drupal.viewsSlideshow && Drupal.viewsSlideshow.action) {
            Drupal.viewsSlideshow.action({
              "action": isPaused ? 'pause' : 'play',
              "slideshowID": slideshowID,
              "force": true
            });
          } else if ($.fn.cycle) {
            // Fallback to direct cycle call
            var $cycleTarget = $('#views_slideshow_cycle_teaser_section_' + slideshowID);
            if (!$cycleTarget.length) $cycleTarget = $slider;
            $cycleTarget.cycle(isPaused ? 'pause' : 'resume');
          }
        });
      });

      // 2. Fraction Slider (.fraction-slider)
      // Narrowed selector to avoid double-matching the wrapper and the slider itself
      once('jnu-fraction-slider-control', '.fraction-slider', context).forEach(function (slider) {
        var $slider = $(slider);
									
        
        // Skip if single slide
        var slideCount = $slider.find('.slide').length;
        if (slideCount <= 1) return;

        createPlayPauseButton($slider.parent(), function (isPaused) {
          if ($.fn.fractionSlider) {
            $slider.fractionSlider(isPaused ? 'pause' : 'resume');
          }
        });
      });

      // 3. Owl Carousel (.owl-carousel)
      once('jnu-owl-slider-control', '.owl-carousel', context).forEach(function (slider) {
        var $slider = $(slider);
        
        createPlayPauseButton($slider.parent(), function (isPaused) {
          $slider.trigger(isPaused ? 'stop.owl.autoplay' : 'play.owl.autoplay');
        });
      });

      /**
       * Helper to create and attach a play/pause button.
       */
      function createPlayPauseButton($container, toggleCallback) {
        // Avoid adding multiple buttons to the same container
        if ($container.hasClass('has-jnu-control') || $container.find('> .jnu-slider-toggle').length) return;
        $container.addClass('has-jnu-control');

        // Ensure container is not static so button can be positioned
        if ($container.css('position') === 'static') {
          $container.css('position', 'relative');
        }

															  
																   

        var $button = $('<button/>', {
          'class': 'jnu-slider-toggle',
          'type': 'button',
          'aria-label': 'Pause slideshow',
          'aria-pressed': 'false',
          'html': '<i class="fa fa-pause"></i>'
        });

        // Styling the button (Circular, MeitY style)
        $button.css({
          'position': 'absolute',
          'right': '20px',
          'bottom': '20px',
          'z-index': '9999',
          'background': 'rgba(0, 0, 0, 0.8)',
          'color': '#fff',
          'border': '2px solid #fff',
          'width': '44px',
          'height': '44px',
          'cursor': 'pointer',
          'font-size': '18px',
          'border-radius': '50%',
          'transition': 'all 0.3s ease',
          'outline': 'none',
          'display': 'flex',
          'align-items': 'center',
          'justify-content': 'center',
          'box-shadow': '0 2px 10px rgba(0,0,0,0.3)'
        });

        // Hover effect
        $button.hover(
          function() { $(this).css({'background': '#fff', 'color': '#000', 'transform': 'scale(1.1)'}); },
          function() { $(this).css({'background': 'rgba(0, 0, 0, 0.8)', 'color': '#fff', 'transform': 'scale(1)'}); }
        );

        // Toggle logic
        $button.on('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          
          var isCurrentlyPaused = $(this).attr('aria-pressed') === 'true';
          var newState = !isCurrentlyPaused;

          $(this).attr('aria-pressed', newState);
          $(this).attr('aria-label', newState ? 'Play slideshow' : 'Pause slideshow');
          $(this).html(newState ? '<i class="fa fa-play" style="margin-left: 3px;"></i>' : '<i class="fa fa-pause"></i>');

          toggleCallback(newState);
        });

        $container.append($button);
      }
    }
  };

})(jQuery, Drupal, once);

// Fix for Fraction Slider accessibility (retaining existing logic but ensuring it works with new buttons)
(function ($, Drupal) {
  Drupal.behaviors.jnuFractionSliderFix = {
    attach: function (context) {
      function fixFractionSliderAccessibility() {
        document.querySelectorAll(".fraction-slider a.prev, .fraction-slider a.next").forEach(function(el){
          var label = el.classList.contains('prev') ? 'Previous slide' : 'Next slide';
          if(el.innerHTML.trim() === ""){
            el.innerHTML = '<span class="visually-hidden">'+label+'</span>';
          }
          el.setAttribute("aria-label", label);
          el.setAttribute("role", "button");
          el.setAttribute("tabindex", "0");
        });

        document.querySelectorAll(".fraction-slider .fs-pager-wrapper a").forEach(function(el, index){
          if(el.innerHTML.trim() === ""){
            el.innerHTML = '<span class="visually-hidden">Slide '+(index+1)+'</span>';
          }
          el.setAttribute("aria-label", "Go to slide "+(index+1));
          el.setAttribute("role", "button");
          el.setAttribute("tabindex", "0");
        });
      }
      fixFractionSliderAccessibility();
      setTimeout(fixFractionSliderAccessibility, 1000);
      setTimeout(fixFractionSliderAccessibility, 2000);
    }
  };
})(jQuery, Drupal);

/**
   * Font Size Consistency and Resizer (WCAG 1.4.4)
   * Integrates with existing #text_resize controls.
   */
   /*
(function ($, Drupal) {
  Drupal.behaviors.jnuFontSizeEnforcer = {
    attach: function (context) {
      var mainSelectors = '.region-content, [role="main"], .sec2bx1, .homesec2, .homesec3, .homesec4, .linksec1';
      var textElements = 'p, span, h1, h2, h3, h4, h5, h6, li, a, td, b, strong, em, i';

      function cleanContent() {
        $(mainSelectors, context).find(textElements).each(function() {
          // If the element has inline font-size (often from CKEditor), it breaks scaling.
          // We remove it to allow the CSS variables to take control.
          if (this.style.fontSize) {
            this.style.setProperty('font-size', '', 'important');
          }
        });
        
        // Specific fix for .text-align-justify which user mentioned
        $('.text-align-justify', context).each(function() {
           if (this.style.fontSize) {
             this.style.setProperty('font-size', '', 'important');
           }
        });
      }

      // Clean immediately on load/AJAX
      cleanContent();
      
      // Listen for resizing events to re-clean (in case dynamic elements were added)
      $(window).off('jnu-font-size-changed.enforcer').on('jnu-font-size-changed.enforcer', function() {
        cleanContent();
      });

      // Extra safety for slow-loading dynamic content
      setTimeout(cleanContent, 1000);
      setTimeout(cleanContent, 3000);
    }
  };
})(jQuery, Drupal);
*/

/**
* Text Spacing Toggle (WCAG 1.4.12)
*/
(function ($, Drupal) {
const toggleBtn = document.getElementById("toggleTextSpace");
const root = document.body;

function applySpacing(enable) {
  if (enable) {
    root.classList.add("text-spacing-enabled");
    toggleBtn.setAttribute("aria-pressed", "true");
  } else {
    root.classList.remove("text-spacing-enabled");
    toggleBtn.setAttribute("aria-pressed", "false");
  }

  localStorage.setItem("textSpacing", enable);
}

// Click event
toggleBtn.addEventListener("click", function (e) {
  e.preventDefault();

  const isEnabled = root.classList.contains("text-spacing-enabled");
  applySpacing(!isEnabled);
});


// Page load (only if user previously chose)
window.addEventListener("DOMContentLoaded", function () {
  const saved = localStorage.getItem("textSpacing");

  if (saved !== null) {
    applySpacing(saved === "true");
  }
});
})(jQuery, Drupal);

/* Language switcher popup with path preservation */
(function (Drupal, once) {

  Drupal.behaviors.languageSwitchAlert = {
    attach: function (context, settings) {

      once('languageSwitchAlert', '#block-jnu-language', context).forEach(function (block) {

        block.querySelectorAll('a').forEach(function (link) {

          link.addEventListener('click', function (e) {

            e.preventDefault();

            let message = "";

            // Current path
            let currentPath = window.location.pathname;

            // Remove existing /hi if present
            currentPath = currentPath.replace(/^\/hi/, '');

            // Avoid empty path
            if (currentPath === '') {
              currentPath = '/';
            }

            let targetUrl = '';

            // -----------------------------------
            // ENGLISH → HINDI
            // -----------------------------------

            if (link.getAttribute("href") === "/hi") {

              message = "Do you want to change website language in Hindi?";

              targetUrl = '/hi' + currentPath;
            }

            // -----------------------------------
            // HINDI → ENGLISH
            // -----------------------------------

            else {

              message = "क्या आप वेबसाइट पर अंग्रेजी भाषा में परिवर्तित करना चाहते हैं ?";

              targetUrl = currentPath;
            }

            // -----------------------------------
            // CONFIRM
            // -----------------------------------

            if (confirm(message)) {

              window.location.href = targetUrl;
            }

          });

        });

      });

    }
  };

})(Drupal, once);
/**HTML attribute change in html tag**/
(function (Drupal) {
  Drupal.behaviors.setHtmlLang = {
    attach: function (context, settings) {

      var path = window.location.pathname;

      if (path.startsWith('/hi')) {
        document.documentElement.lang = 'hi';
      } else {
        document.documentElement.lang = 'en';
      }

    }
  };
})(Drupal);


/**Script for Tooltip**/

(function (Drupal, once) {

  Drupal.behaviors.jnuAccessibleTooltips = {
    attach: function (context) {

      once('jnu-tooltips', 'a, button, img, input[type="button"], input[type="submit"]', context)
        .forEach(function (el) {

          // STEP 1: Add missing title
          if (!el.getAttribute('title')) {

            let text = '';

            // Priority order
            if (el.getAttribute('aria-label')) {
              text = el.getAttribute('aria-label');
            } 
            else if (el.getAttribute('alt')) {
              text = el.getAttribute('alt');
            } 
            else if (el.textContent.trim()) {
              text = el.textContent.trim();
            } 
            else if (el.getAttribute('href')) {
              // Extract filename from URL
              let url = el.getAttribute('href');
              let fileName = url.split('/').pop().split('?')[0];

              if (fileName) {
                text = fileName.replace(/[-_]/g, ' ').replace(/\.[^/.]+$/, '');
              }
            }

            if (text) {
              el.setAttribute('title', text);
            }
          }

          // STEP 2: Create custom tooltip element
          let tooltip;

          function showTooltip() {
            let title = el.getAttribute('title');
            if (!title) return;

            tooltip = document.createElement('div');
            tooltip.className = 'jnu-tooltip';
            tooltip.innerText = title;

            document.body.appendChild(tooltip);

            let rect = el.getBoundingClientRect();

            tooltip.style.position = 'absolute';
            tooltip.style.top = (rect.top + window.scrollY - 35) + 'px';
            tooltip.style.left = (rect.left + window.scrollX) + 'px';
          }

          function hideTooltip() {
            if (tooltip) {
              tooltip.remove();
              tooltip = null;
            }
          }

          // STEP 3: Bind BOTH hover + focus
          //el.addEventListener('mouseenter', showTooltip);
          //el.addEventListener('focus', showTooltip);

          //el.addEventListener('mouseleave', hideTooltip);
          //el.addEventListener('blur', hideTooltip);

        });

    }
  };

})(Drupal, once);

/*Back to top button*/
(function (Drupal) {
  Drupal.behaviors.scrollTopButton = {
    attach: function (context, once) {

      const btn = document.getElementById("scrollTopBtn");
      if (!btn) return;

      window.addEventListener("scroll", function () {
        if (window.scrollY > 200) {
          btn.classList.add("show");
        } else {
          btn.classList.remove("show");
        }
      });

      btn.addEventListener("click", function () {
        window.scrollTo({
          top: 0,
          behavior: "smooth"
        });
      });

    }
  };
})(Drupal); 

/***Back to previous page****/
(function (Drupal, once) {
  Drupal.behaviors.jnuBackLink = {
    attach: function (context) {

      const elements = once
        ? once('jnu-back-link', context.querySelectorAll('#backLink'))
        : context.querySelectorAll('#backLink');

      elements.forEach(function (el) {

        // Hide on homepage
        if (document.body.classList.contains("path-frontpage")) {
          el.style.display = "none";
          return;
        }

        // Get referrer
        var ref = document.referrer;

        // Hide if no valid same-domain referrer
        if (!ref || ref.indexOf(window.location.origin) !== 0) {
          el.style.display = "none";
          return;
        }

        // 🔥 Use setTimeout to escape interfering scripts
        el.addEventListener('click', function (e) {
          e.preventDefault();

          setTimeout(function () {
            window.location.href = ref;
          }, 10);

        });

      });

    }
  };
})(Drupal, once);


/***PDF icons and size***/
(function (Drupal, once) {
  Drupal.behaviors.jnuPdfEnhancer = {
    attach: function (context) {

      const container = context.querySelector('.region-content');
      if (!container) return;

      const links = once
        ? once('jnu-pdf-enhancer', container.querySelectorAll('a[href$=".pdf"]'))
        : container.querySelectorAll('a[href$=".pdf"]');

      links.forEach(function (link) {
		  
		 // ❌ Skip image-based PDF links
	    if (link.querySelector('img')) {
		  return;
	    } 

        if (link.classList.contains('pdf-processed')) return;
        link.classList.add('pdf-processed');

		let url = link.href;

		// Convert index.php file URLs to direct file URLs
		url = url.replace('/index.php/sites/', '/sites/');

		// Normalize domain
		url = url.replace(/^https?:\/\/jnu\.ac\.in/i, 'https://www.jnu.ac.in');

		// Remove hash
		url = url.split('#')[0];
  
		// Convert to absolute URL safely
		url = new URL(url, window.location.origin).href;

		// Normalize domain mismatch
		url = url.replace(/^https:\/\/jnu\.ac\.in/i, 'https://www.jnu.ac.in');

        let titleText = link.textContent.trim();
        titleText = titleText.replace(/PDF\s*\(.*?\)/i, '').trim();

        let language = 'English';
        if (link.textContent.match(/hindi|हिंदी/i)) {
          language = 'Hindi';
        }

        const icon = document.createElement('i');
        icon.className = 'fa fa-file-pdf-o pdf-icon';
        icon.setAttribute('aria-hidden', 'true');

        fetch(url, { method: 'HEAD' })
          .then(response => {
            let size = response.headers.get('content-length');
            let sizeText = '';

            if (size) {
              let sizeKB = size / 1024;

              // 🔥 Convert to MB if > 1024 KB
              if (sizeKB >= 1024) {
                sizeText = (sizeKB / 1024).toFixed(1) + ' MB';
              } else {
                sizeText = sizeKB.toFixed(0) + ' KB';
              }
            }

            updateLink(link, titleText, language, sizeText, icon);
          })
          .catch(() => {
            updateLink(link, titleText, language, '', icon);
          });

      });

      function updateLink(link, title, language, size, icon) {

		  const parent = link.parentNode;

		  // 🔹 Create wrapper
		  const wrapper = document.createElement('div');
		  wrapper.className = 'pdf-wrapper';

		  // 🔹 Create NEW clickable link (only title + icon)
		  const newLink = document.createElement('a'); 
		  newLink.href = link.href;
		  newLink.target = '_blank';

		  const titleSpan = document.createElement('span');
		  titleSpan.textContent = title + ' ';

		  const iconClone = icon.cloneNode(true);

		  newLink.appendChild(titleSpan);
		  newLink.appendChild(iconClone);

		  // 🔹 Meta line (NOT clickable)
		  const metaLine = document.createElement('div');
		  metaLine.className = 'pdf-meta';

		  let metaHTML = '<span class="pdf-label">Format:</span> PDF';
		  
		  if (language) {
		    metaHTML += ', <span class="pdf-label">Language:</span> ' + language;
		  }

		  if (size) {
			metaHTML += ', <span class="pdf-label">Size:</span> ' + size;
		  }

		  metaLine.innerHTML = '(' + metaHTML + ')';

		  // Append elements
		  wrapper.appendChild(newLink);
		  wrapper.appendChild(metaLine); 

		  // Replace old link
		  parent.replaceChild(wrapper, link);

		  // Accessibility
		  newLink.setAttribute(
			'aria-label',
			'Download PDF file: ' + title + (size ? ', Size ' + size : '')
		  );
		}

    }
  };
})(Drupal, once);

//NVDA Reader to allow for sub menus
(function (Drupal, once) {
  Drupal.behaviors.jnuMenuAccessibility = {
    attach: function (context) {

      const isHindi =
        document.documentElement.lang === 'hi' ||
        window.location.pathname.startsWith('/hi');

      const items = once(
        'jnu-menu-access',
        context.querySelectorAll('.we-mega-menu-li[data-submenu="1"]')
      );

      items.forEach(function (li) {

        const link = li.querySelector(':scope > a');
        const submenu = li.querySelector(':scope > .we-mega-menu-submenu');

        if (!link || !submenu) return;

        link.setAttribute('tabindex', '0');
        link.setAttribute('aria-haspopup', 'true');
        link.setAttribute('aria-expanded', 'false');

        submenu.setAttribute('aria-hidden', 'true');

        const hint = document.createElement('span');
        hint.className = 'visually-hidden';
        hint.textContent = isHindi
          ? 'उप मेनू खोलने के लिए एंटर या टैब दबाएं'
          : 'Press Enter or Tab to open submenu';

        link.appendChild(hint);

        link.addEventListener('focus', function () {
          li.classList.add('open');
          submenu.style.display = 'block';

          link.setAttribute('aria-expanded', 'true');
          submenu.setAttribute('aria-hidden', 'false');
        });

        li.addEventListener('focusin', function () {
          li.classList.add('open');
          submenu.style.display = 'block';
        });

        li.addEventListener('focusout', function () {
          setTimeout(function () {
            if (!li.contains(document.activeElement)) {
              li.classList.remove('open');
              submenu.style.display = 'none';

              link.setAttribute('aria-expanded', 'false');
              submenu.setAttribute('aria-hidden', 'true');
            }
          }, 100);
        });

        link.addEventListener('keydown', function (e) {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            link.focus();
          }
        });

      });

    }
  };
})(Drupal, once);

/********Autocomplete Off in search**********/
document.addEventListener("DOMContentLoaded", function () {

  // Select search input (Drupal default selector)
  const searchInput = document.querySelector('#edit-keys');

  if (searchInput) {
    // Fix invalid autocomplete value
    if (searchInput.getAttribute('autocomplete') === 'search' || !searchInput.hasAttribute('autocomplete')) {
      searchInput.setAttribute('autocomplete', 'on');
    }

    // Ensure accessible label exists
    if (!document.querySelector('label[for="edit-keys"]')) {
      const label = document.createElement('label');
      label.setAttribute('for', 'edit-keys');
      label.className = 'visually-hidden';
      label.innerText = 'Search the site';

      searchInput.parentNode.insertBefore(label, searchInput);
    }
  }

});

/************Add Pdf icon and its size on home page only*********/
(function (Drupal, once) {
  Drupal.behaviors.jnuPdfInline = {
    attach: function (context) {

      const isHindi =
        document.documentElement.lang === 'hi' ||
        window.location.pathname.startsWith('/hi');

      const textLabels = {
        format: isHindi ? ' फॉर्मेट: PDF' : ' Format: PDF',
        size: isHindi ? 'आकार' : 'Size'
      };

      // 🔵 MAIN PROCESS FUNCTION (Reusable)
      function processPdfLinks(scope) { 

        const links = scope.querySelectorAll('a[href$=".pdf"]');

        links.forEach(function (link) {

          if (link.classList.contains('pdf-inline-processed')) return;
          link.classList.add('pdf-inline-processed');

		let url = link.href;

		// Convert index.php file URLs to direct file URLs
		url = url.replace('/index.php/sites/', '/sites/');

		// Normalize domain
		url = url.replace(/^https?:\/\/jnu\.ac\.in/i, 'https://www.jnu.ac.in');

		// Remove hash
		url = url.split('#')[0];

          // 🔴 Fix Hindi path issue
          url = url.replace(/\/hi\/sites\//, '/sites/');
          url = new URL(url, window.location.origin).href;

          // ✅ Create icon
          const icon = document.createElement('i');
          icon.className = 'fa fa-file-pdf-o pdf-icon';
          icon.setAttribute('aria-hidden', 'true');

          // 🔴 Fetch size
          fetch(url, { method: 'HEAD' })
            .then(res => {

              let size = res.headers.get('content-length');
              let sizeText = '';

              if (size && size !== '0') {
                let kb = size / 1024;
                sizeText = kb >= 1024
                  ? (kb / 1024).toFixed(1) + ' MB'
                  : Math.round(kb) + ' KB';
              }

              updateInline(link, sizeText, icon);

            })
            .catch(() => {
              updateInline(link, '', icon);
            });

        });
      }

      // 🔵 INITIAL LOAD
      const containers = once('jnu-pdf-inline', context.querySelectorAll(
        '.region-admissions, .region-notices, .top-nav, .submenu, .main-menu, .tick, .custom-academic-output' 
      ));

      containers.forEach(function (container) {
        processPdfLinks(container);
      });

      // 🔥 HANDLE DYNAMIC (3rd LEVEL MENU)
      const observer = new MutationObserver(function (mutations) {

        mutations.forEach(function (mutation) {

          mutation.addedNodes.forEach(function (node) {

            if (node.nodeType !== 1) return;

            if (
              node.matches &&
              (
                node.matches('.we-mega-menu-submenu') ||
                node.querySelector('.we-mega-menu-submenu')
              )
            ) {
              processPdfLinks(node);
            }

          });

        });

      });

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });

      // 🔵 RENDER FUNCTION
      function updateInline(link, size, icon) {

		  if (link.querySelector('.pdf-inline-meta')) return;

		  let language = 'English';

		  if (
			link.textContent.match(/hindi|हिंदी/i) ||
			link.href.match(/hindi|hin/i)
		  ) {
			language = 'Hindi';
		  }

		  link.insertAdjacentText('beforeend', ' ');
		  link.appendChild(icon);

		  const meta = document.createElement('span');
		  meta.className = 'pdf-inline-meta';

		  let text =
			' ' + textLabels.format +
			', Language: ' + language;

		  if (size) {
			text += ', ' + textLabels.size + ': ' + size;
		  }

		  meta.textContent = text;
		  link.appendChild(meta);

		  // Accessibility
		  link.setAttribute(
			'aria-label',
			isHindi
			  ? `${link.textContent} PDF फ़ाइल, भाषा ${language}${size ? ', आकार ' + size : ''}`
			  : `${link.textContent} PDF file, Language ${language}${size ? ', size ' + size : ''}`
		  );
		}

    }
  };
})(Drupal, once);

/***************Feedbackform FIx*********************/
(function (Drupal, once) {

  Drupal.behaviors.jnuAjaxContactForm = {
    attach: function (context) {

      /* =========================
         REMOVE PREVIEW BUTTON
      ========================= */
      once('hide-preview-btn', context.querySelectorAll('#edit-preview')).forEach(function (btn) {
        btn.remove();
      });

      /* =========================
         POPUP FUNCTION (GLOBAL)
      ========================= */
      function showPopup(message) {

        const overlay = document.createElement('div');
        overlay.className = 'jnu-popup-overlay';

        const popup = document.createElement('div');
        popup.className = 'jnu-popup-box';

		popup.innerHTML = `
		  <div class="jnu-popup-content"
			   role="dialog"
			   aria-modal="true"
			   aria-labelledby="jnu-popup-message">

			<h2 id="jnu-popup-message"
				tabindex="-1"
				style="font-size:18px;margin-bottom:20px;">
				${message}
			</h2>

			<button class="jnu-popup-close">
			  OK
			</button>

		  </div>
		`;

        overlay.appendChild(popup);
		
		let liveRegion = document.getElementById('jnu-live-region');

		if (!liveRegion) {

		  liveRegion = document.createElement('div');
		  liveRegion.id = 'jnu-live-region';

		  liveRegion.setAttribute('aria-live', 'assertive');
		  liveRegion.setAttribute('aria-atomic', 'true');

		  liveRegion.style.position = 'absolute';
		  liveRegion.style.left = '-9999px';

		  document.body.appendChild(liveRegion);
		}

		liveRegion.textContent = '';

		setTimeout(function () {
		  liveRegion.textContent = message;
		}, 100);
        document.body.appendChild(overlay);
		const messageElement = popup.querySelector('#jnu-popup-message');

		setTimeout(function () {
		  messageElement.focus();
		}, 100);

		popup.querySelector('.jnu-popup-close').addEventListener('click', function () {

		  overlay.remove();

		  const submitBtn = document.querySelector('#edit-submit');

		  if (submitBtn) {
			submitBtn.focus();
		  }

		});
		
		popup.addEventListener('keydown', function (e) {

		  if (e.key === 'Escape' || e.keyCode === 27) {

			overlay.remove();

			const submitBtn = document.querySelector('#edit-submit');

			if (submitBtn) {
			  submitBtn.focus();
			}

		  }

		});
		
      }

      /* =========================
         AJAX FORM SUBMIT
      ========================= */
      once('jnu-ajax-form', '#contact-message-feedback-form', context).forEach(function (form) {

        const submitBtn = form.querySelector('#edit-submit');

		form.addEventListener('submit', function (e) {

		  // HTML5 validation first
			if (!form.checkValidity()) {

			  e.preventDefault();

			  form.reportValidity();

			  const firstInvalid = form.querySelector(':invalid');

			  if (firstInvalid) {
				firstInvalid.focus();
			  }

			  return;
			}

		  e.preventDefault();

		  if (submitBtn.classList.contains('loading')) {
			return;
		  }

          // Loader state
          submitBtn.classList.add('loading');
          submitBtn.disabled = true;
          submitBtn.dataset.originalText = submitBtn.value;

          const isHindi = window.location.pathname.startsWith('/hi');
          submitBtn.value = isHindi ? 'भेजा जा रहा है...' : 'Sending...';
		   
		  const nameField =
			  form.querySelector('#edit-name') ||
			  form.querySelector('[name="name"]');

			if (nameField) {

			  const nameValue = nameField.value.trim();

			  const namePattern = /^[a-zA-Z\u0900-\u097F\s.'-]+$/;

			  if (!namePattern.test(nameValue)) {

				showPopup(
				  isHindi
					? 'कृपया नाम में केवल अक्षर दर्ज करें।'
					: 'Please enter a valid name using letters only.'
				);

				nameField.focus();

				submitBtn.classList.remove('loading');
				submitBtn.disabled = false;
				submitBtn.value = submitBtn.dataset.originalText;

				return;
			  }
			}

          const formData = new FormData(form);

          fetch(form.action, {
            method: 'POST',
            body: formData,
            headers: {
              'X-Requested-With': 'XMLHttpRequest'
            }
          })
			.then(response => {

			  return response.text().then(data => {
				return {
				  ok: response.ok,
				  data: data
				};
			  });

			})
			.then(result => {

			  const data = result.data;

            const successText = isHindi
              ? 'आपका संदेश सफलतापूर्वक भेज दिया गया है।'
              : 'Your message has been sent successfully.';

            // ✅ CHECK REAL SUCCESS
			const parser = new DOMParser();
			const doc = parser.parseFromString(data, 'text/html');

			if (result.ok) {

              showPopup(successText);
              form.reset();

            } else {

			  const error = doc.querySelector(
				  '.messages--error, .messages.error, [role="alert"]'
				);

			  if (error) {

				showPopup(error.textContent.trim());

			  } else {

				showPopup(isHindi
				  ? 'सबमिशन असफल रहा। कृपया पुनः प्रयास करें।'
				  : 'Submission failed. Please try again.'
				);

			  }

			}

          })
          .catch(() => {

            showPopup(isHindi
              ? 'कुछ गलत हो गया। कृपया पुनः प्रयास करें।'
              : 'Something went wrong. Please try again.'
            );

          })
          .finally(() => {

            // Restore button
            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;
            submitBtn.value = submitBtn.dataset.originalText;

          });

        });

      });

    }
  };

})(Drupal, once);

/***************** **Home page pre footer right section hindi conversion ********************/
(function (Drupal) {
  Drupal.behaviors.jnuVisitorTranslate = {
    attach: function (context) {

      const isHindi =
        document.documentElement.lang === 'hi' ||
        window.location.pathname.startsWith('/hi');

      if (!isHindi) return;

      // ✅ FIX: Use class instead of ID
      const items = document.querySelectorAll(
        '.block-visitors-block li'
      );

      items.forEach(function (el) {

        let html = el.innerHTML;

        if (html.includes('Total Visitors')) {
          el.innerHTML = html.replace('Total Visitors', 'कुल आगंतुक');
        }

        if (html.includes('Since')) {
          el.innerHTML = html.replace('Since', 'उपरान्त');
        }

      });

    }
  };
})(Drupal);

/***********A+ A A- Text resize updates*****************/
	(function (Drupal, once) {
  Drupal.behaviors.jnuTextResize = {
    attach: function (context) {

      const sizes = [10, 12, 14, 16, 18];
      let currentIndex = parseInt(localStorage.getItem('jnuFontSize')) || 2;

      function applySize() {
        document.documentElement.style.fontSize = sizes[currentIndex] + 'px';
        localStorage.setItem('jnuFontSize', currentIndex);
      }

      applySize();

      once('text-resize-controls', context.querySelectorAll('#text_resize_increase, #text_resize_reset, #text_resize_decrease'))
        .forEach(function () {

          const increase = document.getElementById('text_resize_increase');
          const decrease = document.getElementById('text_resize_decrease');
          const reset = document.getElementById('text_resize_reset');

          if (!increase || !decrease || !reset) return;

          // 🌐 Language detection
          const isHindi =
            document.documentElement.lang === 'hi' ||
            window.location.pathname.startsWith('/hi');

          const labels = isHindi
            ? {
                increase: 'टेक्स्ट आकार बढ़ाएं',
                reset: 'टेक्स्ट आकार सामान्य करें',
                decrease: 'टेक्स्ट आकार घटाएं'
              }
            : {
                increase: 'Increase text size',
                reset: 'Reset text size',
                decrease: 'Decrease text size'
              };

          // 🔁 Fix order once
          const parent = increase.parentNode;
          parent.appendChild(increase);
          parent.appendChild(reset);
          parent.appendChild(decrease);

          // 🔧 Apply accessibility + events
          [
            { el: increase, action: 'inc', label: labels.increase },
            { el: reset, action: 'reset', label: labels.reset },
            { el: decrease, action: 'dec', label: labels.decrease }
          ].forEach(({ el, action, label }) => {

            el.setAttribute('tabindex', '0');
            el.setAttribute('role', 'button');
            el.setAttribute('aria-label', label);
            el.setAttribute('title', label);

            el.addEventListener('click', function (e) {
              e.preventDefault();

              if (action === 'inc' && currentIndex < sizes.length - 1) {
                currentIndex++;
              }

              if (action === 'dec' && currentIndex > 0) {
                currentIndex--;
              }

              if (action === 'reset') {
                currentIndex = 2;
              }

              applySize();
            });

            // ✅ Keyboard support
            el.addEventListener('keydown', function (e) {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                el.click();
              }
            });

          });

        });

    }
  };
})(Drupal, once);

/*********************Nav Bar customization********************/

/**************Scroll to top focus*****************/
(function (Drupal, once) {
  Drupal.behaviors.jnuScrollTopFix = {
    attach: function (context) {

      const btn = once(
        'scroll-top-fix',
        context.querySelectorAll('.scroll-top, .back-to-top')
      );

      btn.forEach(function (el) {

        // ✅ Make focusable
        el.setAttribute('tabindex', '0');

        // ✅ Add button role
        el.setAttribute('role', 'button');

        // ✅ Accessible label (Hindi + English)
        const isHindi =
          document.documentElement.lang === 'hi' ||
          window.location.pathname.startsWith('/hi');

        el.setAttribute(
          'aria-label',
          isHindi ? 'ऊपर जाएं' : 'Scroll to top'
        );

        el.setAttribute(
          'title',
          isHindi ? 'ऊपर जाएं' : 'Scroll to top'
        );

        // 🔥 Keyboard support
        el.addEventListener('keydown', function (e) {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            el.click();
          }
        });

      });

    }
  };
})(Drupal, once);

/**************Remove Default theme and other themes from displaying text on top bar***************/
document.addEventListener('DOMContentLoaded', function () {

  document.querySelectorAll('#block-jnu-styleswitcher a').forEach(function (el) {
    
    // Keep accessibility
    const label = el.getAttribute('aria-label');

    // Remove visible text
    el.textContent = '';

    // Optional: keep label for screen readers
    if (label) {
      el.setAttribute('title', label);
    }

  });

});

/****************Overview block hindi translation**********/
/**************** Overview block Hindi translation **************/
(function () {

  document.addEventListener('DOMContentLoaded', function () {

    // Run translations ONLY on Hindi version
    const isHindi =
      document.documentElement.lang === 'hi' ||
      window.location.pathname === '/hi' ||
      window.location.pathname.startsWith('/hi/');

    if (!isHindi) return;

    // ================= TRANSLATION MAP =================
    const translations = {

      // Footer
      "ICC": "आईसीसी",
      "NIRF": "एनआईआरएफ",
      "NAAC": "एनएएसी",
      "ARIIA 2020": "एआरआईआईए 2020",
      "JNU MAIL": "जेनयू मेल",
      "APPS": "एप्स",
      "E-OFFICE": "ई-ऑफिस",

      // Ranking section
      "INDIA TODAY-RANKING 2025": "इंडिया टुडे रैंकिंग 2025",
      "QS WORLD UNIVERSITY RANKING 2026": "क्यूएस वर्ल्ड यूनिवर्सिटी रैंकिंग 2026",
      "WORLD UNIVERSITY RANKINGS 2026": "विश्व विश्वविद्यालय रैंकिंग 2026"
    };


    // ================= SPAN TRANSLATION =================
    function translateSpan(span) {

      let text = span.textContent.trim();
      text = text.replace(/\s+/g, ' ').toUpperCase();

      const matchKey = Object.keys(translations).find(
        key => key.toUpperCase() === text
      );

      if (matchKey) {

        const translated = translations[matchKey];

        span.textContent = translated;

        const link = span.closest('a');

        if (link) {

          link.setAttribute('title', translated);
          link.setAttribute('aria-label', translated);

          const img = link.querySelector('img');

          if (img) {
            img.setAttribute('alt', translated);
          }
        }
      }
    }


    // ================= FOOTER =================
    document
      .querySelectorAll('.tab1bxinr3btmnav li a span')
      .forEach(translateSpan);


    // ================= RANKING =================
    document
      .querySelectorAll('.field--name-body .btn span')
      .forEach(translateSpan);


    // ================= PREVIOUS YEAR DETAILS =================
    document.querySelectorAll('a').forEach(function (link) {

      let text = link.textContent.trim();

      const normalized = text
        .replace(/\s+/g, ' ')
        .toUpperCase();

      if (normalized === 'PREVIOUS YEAR DETAILS') {

        const translated = 'पिछले वर्ष का विवरण';

        link.textContent = translated;
        link.setAttribute('title', translated);
        link.setAttribute('aria-label', translated);
      }

    });

  });

})();
/****************Responsive Menu issues Fix***************/

(function ($, Drupal) {

  Drupal.behaviors.jnuQuicktabsHashOpen = {
    attach: function (context, settings) {

      if (context !== document) {
        return;
      }

      $(window).on('load', function () {

        setTimeout(function () {

          var hash = window.location.hash;

          if (!hash) {
            return;
          }

          // Example:
          // #quicktabs-tab-front_page_qui-3

          var $tab = $(hash).find('a.quicktabs-loaded');

          if ($tab.length) {

            // Trigger REAL Quicktabs click
            $tab.triggerHandler('click');

          }

        }, 1500);

      });

    }
  };

})(jQuery, Drupal); 

/* Photo Gallery confirmation popup + open in new tab */
(function (Drupal, once) {

  Drupal.behaviors.photoGalleryConfirm = {
    attach: function (context, settings) {

      once('photoGalleryConfirm', 'a[href*="/photogallery"]', context).forEach(function (link) {

        // Force new tab
        link.setAttribute('target', '_blank');

        // Security best practice
        link.setAttribute('rel', 'noopener noreferrer');

        link.addEventListener('click', function (e) {

          e.preventDefault();

          let message = '';

          // Detect current language
          const currentPath = window.location.pathname;

          // Hindi
          if (currentPath.startsWith('/hi')) {

            message = 'क्या आप वास्तव में फोटोग्राफ गैलरी पृष्ठ पर जाना चाहते हैं ?';
          }

          // English
          else {

            message = 'Do you really want to go to the Photograph Gallery page?';
          }

          // Confirmation popup
          if (confirm(message)) {

            window.open(link.href, '_blank', 'noopener');
          }

        });

      });

    }
  };

})(Drupal, once);

/****************Responsive Menu issues Fix***************/
jQuery(document).ready(function ($) {

    // MOBILE MENU TOGGLE
    $('.mobile-menu-toggle').click(function () {

        $('.main-menu').toggleClass('mobile-active');

        let expanded =
            $(this).attr('aria-expanded') === 'true';

        $(this).attr('aria-expanded', !expanded);

    });

    // SUBMENU TOGGLE
    $(document).on('click', '.menu-toggle', function (e) {

        e.preventDefault();
        e.stopPropagation();

        $(this).parent().toggleClass('active-submenu');

        let expanded =
            $(this).attr('aria-expanded') === 'true';

        $(this).attr('aria-expanded', !expanded);

    });

});

/* ======================================================
   FINAL MOBILE MENU SCRIPT
====================================================== */

document.addEventListener('DOMContentLoaded', function () {

    // MOBILE HAMBURGER
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    const mainMenu = document.querySelector('.main-menu');

    if (mobileToggle && mainMenu) {

        mobileToggle.addEventListener('click', function () {

            mainMenu.classList.toggle('mobile-active');

            let expanded = mobileToggle.getAttribute('aria-expanded') === 'true';

            mobileToggle.setAttribute('aria-expanded', !expanded);
        });
    }

    // SUBMENU TOGGLES
    const menuButtons = document.querySelectorAll('.menu-toggle');

    menuButtons.forEach(function(button) {

        button.addEventListener('click', function(e) {

            // MOBILE ONLY
            if (window.innerWidth <= 991) {

                e.preventDefault();

                const submenu = button.nextElementSibling;

                if (submenu) {

                    submenu.classList.toggle('mobile-submenu-open');

                    let expanded =
                        button.getAttribute('aria-expanded') === 'true';

                    button.setAttribute('aria-expanded', !expanded);
                }
            }
        });
    });

});

/* ======================================================
   FINAL DRUPAL MOBILE MENU FIX
====================================================== */
jQuery(document).ready(function ($) {

    $('.mobile-menu-toggle').on('click', function (e) {

        e.preventDefault();

        $('.main-menu').toggleClass('mobile-active');

    });

});
/******Mobile version image straching issue fix******/
(function ($, Drupal) {

  Drupal.behaviors.jnuMobileSliderFix = {
    attach: function (context, settings) {

      function fixMobileSlider() {

        if (window.innerWidth <= 991) {

          // FIX ONLY IMAGE
          $('.views_slideshow_cycle_slide img').css({
            width: '100%',
            height: 'auto',
            maxWidth: '100%'
          });

          // PREVENT FIXED WIDTH
          $('.views_slideshow_cycle_teaser_section').css({
            maxWidth: '100%'
          });

          $('.views_slideshow_cycle_slide').css({
            maxWidth: '100%'
          });

        }

      }

      fixMobileSlider();

      $(window).on('resize orientationchange', function () {
        fixMobileSlider();
      });

    }
  };

})(jQuery, Drupal);

/************ GLOBAL PDF URL FIX *************/
(function (Drupal, once) {

  Drupal.behaviors.jnuGlobalPdfFix = {
    attach: function (context) {

      const pdfLinks = once(
        'jnu-global-pdf-fix',
        'a[href$=".pdf"]',
        context
      );

      pdfLinks.forEach(function (link) {

        let url = link.href;

        // 🔵 Remove Drupal index.php from URLs
        url = url.replace('/index.php/', '/');

        // 🔵 Fix duplicated sites path
        url = url.replace('/index.php/sites/', '/sites/');

        // 🔵 Normalize non-www → www
        url = url.replace(
          /^https?:\/\/jnu\.ac\.in/i,
          'https://www.jnu.ac.in'
        );

        // 🔵 Remove hash/anchors
        url = url.split('#')[0];

        // 🔵 Update actual link
        link.href = url;

      });

    }
  };

})(Drupal, once);

/************ Homepage Confirmation Popup for Selected Links Only *************/
(function (Drupal, once) {

  Drupal.behaviors.jnuHomePopupLinks = {
    attach: function (context) {

      // Homepage only
      const path = window.location.pathname.replace(/\/$/, '');

		const isHomepage =
		  path === '' ||
		  path === '/' ||
		  path === '/node' ||
		  path === '/index.php' ||
		  path === '/hi' ||
		  path === '/hi/node';
		  
      if (!isHomepage) {
        return;
      }

      // Allowed URL keywords ONLY
      const allowedUrls = [
        '/intranet',
        '/iha_admin',
        '/alumni-affairs',
        '/research',
        '/iqac',
        '/ic',
		'/hindi-research',

        // Schools
        '/abvsme',
        '/saa',
        '/sbt',
        '/scis',
        '/scss',
        '/ses',
        '/sis',
        '/sllcs',
        '/sls',
        '/sps',
        '/ssis',
        '/sss',

        // Special Centres
        '/cslg',
        '/scdr',
        '/scmm',
        '/scns',
        '/scnss',
        '/scts',
        '/scsnei',

        // SIS Centres
        '/sis/cas',
        '/sis/csa',
        '/sis/ccppt',
        '/sis/ceas',
        '/sis/ces',
        '/sis/cips',
        '/sis/cias',
        '/sis/cils',
        '/sis/cipod',
        '/sis/cswe',
        '/sis/crcas',
        '/sis/csas',
        '/sis/cwas',

        // SLLCS Centres
        '/sllcs/caas',
        '/sllcs/ccs',
        '/sllcs/ces',
        '/sllcs/cffs',
        '/sllcs/cgs',
        '/sllcs/cil',
        '/sllcs/cjs',
        '/sllcs/cks',
        '/sllcs/cl',
        '/sllcs/cpcas',
        '/sllcs/crs',
        '/sllcs/cspilas',

        // SSS Centres
        '/sss/cesp',
        '/sss/chs',
        '/sss/cisls',
        '/sss/cms',
        '/sss/cp',
        '/sss/cps',
        '/sss/csmch',
        '/sss/cssp',
        '/sss/cssi',
        '/sss/csrd',
        '/sss/csss',
        '/sss/cws',
        '/sss/zhces',
		// Hindi Schools
		'/hindi-saa',
		'/hindi-sbt',
		'/hindi-scis',
		'/hindi-scss',
		'/hindi-ses',
		'/hindi-sls',
		'/hindi-sps',
		'/hindi-scmm',
		'/hindi-scns',
		'/hindi-cslg',

		// SIS Hindi
		'/sis/hindi',
		'/sis/hindi-cas',
		'/sis/hindi-ccuslas',
		'/sis/hindi-ccppt',
		'/sis/hindi-ceas',
		'/sis/hindi-ces',
		'/sis/hindi-cias',
		'/sis/hindi-cils',
		'/sis/hindi-cipod',
		'/sis/hindi-cswe',
		'/sis/hindi-crcas',
		'/sis/hindi-csas',

		// SLLCS Hindi
		'/sllcs/hindi',
		'/sllcs/hindi-caas',
		'/sllcs/hindi-ccseas',
		'/sllcs/hindi-ces',
		'/sllcs/hindi-cffs',
		'/sllcs/hindi-cgs',
		'/sllcs/hindi-cil',
		'/sllcs/hindi-cjs',
		'/sllcs/hindi-cks',
		'/sllcs/hindi-cl',
		'/sllcs/hindi-cpcas',
		'/sllcs/hindi-crs',
		'/sllcs/hindi-cspilas',

		// SSS Hindi
		'/sss/hindi-cesp',
		'/sss/hindi-chs',
		'/sss/hindi-cisls',
		'/sss/hindi-cms',
		'/sss/hindi-cp',
		'/sss/hindi-cps',
		'/sss/hindi-csmch',
		'/sss/hindi-cssp',
		'/sss/hindi-csde',
		'/sss/hindi-csrd',
		'/sss/hindi-csss',
		'/sss/hindi-cws',
		'/sss/hindi-zhces',
		'/nad-abc',
		'/nss',
		'/placementcell',
		'/airf',
		'/cis',
		'/convention',
		'/iha-hostel',
		'/usic', 
		'/hi/hindi-cis',
		'/hi/hindi-convention',
		'/hi/hindi-cis',
		'/ibsc',
		'/ipm',
		'/vikas',
		'/ierb',
		'/trc',
		'/gian',
		'/iic',
		'/lec',
		'/mmttc',
		'/hi/hindi-gian',
		'/hi/hindi-ipm',
		'/hi/hindi-lec',
		'/hi/hindi-trc', 
      ];

      // Process all links
      once('jnu-home-popup-links', 'a[href]', context)
        .forEach(function (link) {

          const href = link.getAttribute('href') || '';

          // ONLY allowed URLs
          // Build URL safely
			const parsedUrl = new URL(
			  href,
			  window.location.origin
			);

			// Get normalized pathname
			const normalizedPath =
			  parsedUrl.pathname.toLowerCase();

			// Match only beginning of path
			const shouldApply = allowedUrls.some(function (item) {

			  const cleanItem = item.toLowerCase();

			  return (
				normalizedPath === cleanItem ||
				normalizedPath.indexOf(cleanItem + '/') === 0 ||
				normalizedPath.indexOf('/hi' + cleanItem) === 0
			  );

			});

          if (!shouldApply) {
            return;
          }

          // Prevent double popup
          link.setAttribute(
            'data-jnu-popup-handled',
            'true'
          );

          // Open in new tab
          link.setAttribute('target', '_blank');
          link.setAttribute(
            'rel',
            'noopener noreferrer'
          );

          link.addEventListener('click', function (e) {

            e.preventDefault();

            // Build proper URL
            const fullUrl = new URL(
              href,
              window.location.origin
            ).href;

            // Link title
            let pageName = link.textContent.trim();

            if (!pageName && link.title) {
              pageName = link.title.trim();
            }

            if (!pageName) {
              pageName = 'this page';
            }

            // Language
            const isHindi =
              window.location.pathname.startsWith('/hi');

            let message = '';

            if (isHindi) {

              message =
                'क्या आप वास्तव में "' +
                pageName +
                '" पृष्ठ खोलना चाहते हैं ?';

            } else {

              message =
                'Do you really want to open the "' +
                pageName +
                '" page?';
            }

            // Popup
            if (confirm(message)) {
              window.open(fullUrl, '_blank', 'noopener');
            }

          });

        });

    }
  };

})(Drupal, once); 

/************ Remove index.php from URLs *************/
(function () {

  // Current full URL
  var currentUrl = window.location.href;

  // Check if index.php exists
  if (currentUrl.indexOf('/index.php/') !== -1) {

    // Remove index.php
    var cleanUrl = currentUrl.replace('/index.php/', '/');

    // Redirect safely
    window.location.replace(cleanUrl);
  }

})();

/************ Hindi Site → English Page Warning Popup *************/
(function (Drupal, once) {

  Drupal.behaviors.jnuHindiEnglishWarning = {
    attach: function (context) {

      // ONLY Hindi pages
      const currentPath =
	  window.location.pathname.replace(/\/$/, '');

		const isHindiPage =
		  currentPath === '/hi' ||
		  currentPath === '/hi/node' ||
		  currentPath.startsWith('/hi/');

      if (!isHindiPage) {
        return;
      }

      // English-only pages
      const englishOnlyUrls = [

        '/career',
        '/content/jnu-achievements',
        '/tender',
        '/intranet',
        '/gallery',
        '/airf',
        '/alumni',
        '/ekta-diwas',
        '/nirf',
        '/announcements',
        '/nad-abc',
        '/viksitbharat',
        '/financial-aid',
        '/antiraggingcell',
        '/content/NewStudentsRegistration',
        '/content/registration',
        '/content/PMRF',
        '/results_notices',
        '/hindi-parliament-question',
        '/public-self-disclosure',
        '/meugc',
        '/hi/content/procedure-univ-certificate',
        '/grievanceredressal',
        '/placementcell',
        '/hi/hindi-students-activities',
        '/group-a-officer',
        '/faculty-books',
        '/accreditation-ranking',
        '/qsranking',
        '/students_achievements',
        '/fitjnu',
        '/yogaday2023',
        '/hi/report',
        '/hi/faculty-details2'
      ];

      once(
        'jnu-hindi-english-warning',
        'a[href]',
        context
      ).forEach(function (link) {

        const href =
          link.getAttribute('href') || '';

        // Skip empty/hash/js links
        if (
          href === '#' ||
          href.indexOf('javascript:') === 0
        ) {
          return;
        }

        // Build full URL safely
        let parsedUrl;

        try {

          parsedUrl = new URL(
            href,
            window.location.origin
          );

        } catch (e) {

          return;
        }

        const normalizedPath =
          parsedUrl.pathname.toLowerCase();

        // Apply ONLY to selected URLs
        const shouldApply =
          englishOnlyUrls.some(function (item) {

            return (
              normalizedPath === item ||
              normalizedPath.indexOf(item + '/') === 0
            );

          });

        if (!shouldApply) {
          return;
        }

        // Avoid duplicate popup
        if (
          link.hasAttribute(
            'data-jnu-hindi-warning'
          )
        ) {
          return;
        }

        link.setAttribute(
          'data-jnu-hindi-warning',
          'true'
        );

        // Open in new tab
        link.setAttribute(
          'target',
          '_blank'
        );

        link.setAttribute(
          'rel',
          'noopener noreferrer'
        );

        link.addEventListener('click', function (e) {

          e.preventDefault();

          const message =
            'यह पृष्ठ हिंदी में उपलब्ध नहीं है। क्या आप अंग्रेजी संस्करण खोलना चाहते हैं?';

          if (confirm(message)) {

            window.open(
              parsedUrl.href,
              '_blank',
              'noopener'
            );

          }

        });

      });

    }
  };

})(Drupal, once);

/*******To open all pdfs into new tab******/
document.addEventListener('DOMContentLoaded', function () {

  document.querySelectorAll('a[href$=".pdf"]').forEach(function(link) {

    link.setAttribute('target', '_blank');
    link.setAttribute('rel', 'noopener noreferrer');

  });

});
/****************For SCHOOL AND CENTRES Sub Menu*****************/

(function ($, Drupal) {

  Drupal.behaviors.jnuQuickTabs = {
    attach: function (context, settings) {

      const urlParams = new URLSearchParams(window.location.search);
      const tab = urlParams.get('tab');

      const tabs = {
        'schools-centres': 3,
        'students': 4
      };

      if (tabs[tab] !== undefined) {

        setTimeout(function () {

          $('#quicktabs-tab-front_page_qui-' + tabs[tab] + ' a').trigger('click');

          $('html, body').stop().animate({
            scrollTop: $('#quicktabs-tab-front_page_qui-' + tabs[tab]).offset().top - 150
          }, 1000);

        }, 1000);

      }

    }
  };

})(jQuery, Drupal);

/*****************To update international phone numbers***************/

(function ($, Drupal) {

  Drupal.behaviors.jnuPhonePrefixFix = {
    attach: function (context, settings) {

      $('body', context).find('*').contents().filter(function () {
        return this.nodeType === 3;
      }).each(function () {

        this.nodeValue = this.nodeValue.replace(
          /\b011-(\d{8})\b/g,
          '+91-11-$1'
        );

      });

    }
  };

})(jQuery, Drupal);

/************Tender page search form placeholder*************/

(function ($, Drupal, once) {

  Drupal.behaviors.jnuTenderSearchPlaceholder = {
    attach: function (context) {

      once('jnu-tender-placeholder', '#edit-title', context).forEach(function (element) {

        var placeholder = 'Search Tender';

        if (document.documentElement.lang === 'hi') {
          placeholder = 'निविदा खोजें';
        }

        element.setAttribute('placeholder', placeholder);

      });

    }
  };

})(jQuery, Drupal, once);

/*******************Main Menu -  Esc will skip the menu**************/
(function ($, Drupal, once) {

  Drupal.behaviors.jnuMenuEscapeNavigation = {
    attach: function (context) {

      once('jnu-menu-escape', 'body', context).forEach(function () {

        // ESC from submenu items
        $(document).on('keydown', '.submenu a, .submenu button', function (e) {

          if (e.key === 'Escape' || e.keyCode === 27) {

            e.preventDefault();
            e.stopPropagation();

            var $parentLi = $(this).closest('.submenu').closest('li');
            var $parentButton = $parentLi.children('a, button').first();

            $parentButton.attr('aria-expanded', 'false');
            $parentLi.removeClass('open active');

            var $nextTopMenu = $parentLi.next('li');

            setTimeout(function () {

              if ($nextTopMenu.length) {
                $nextTopMenu.find('> a, > button').first().focus();
              }

            }, 50);
          }
        });

        // ESC from Administration button itself
        $(document).on('keydown', '.menu-toggle', function (e) {

          if (e.key === 'Escape' || e.keyCode === 27) {

            e.preventDefault();
            e.stopPropagation();

            var $parentLi = $(this).closest('li');

            $(this).attr('aria-expanded', 'false');
            $parentLi.removeClass('open active');

            var $nextTopMenu = $parentLi.next('li');

            if ($nextTopMenu.length) {
              $nextTopMenu.find('> a, > button').first().focus();
            }
          }

        });

      });

    }
  };

})(jQuery, Drupal, once);

/************Add placeholder in catcha field***************/
document.getElementById('edit-captcha-response')
        .setAttribute('placeholder', 'Enter captcha');
		
/***************Math captcha should be readable***********/
(function ($, Drupal, once) {

  Drupal.behaviors.jnuCaptchaAccessibility = {
    attach: function (context) {

      once('jnu-captcha-a11y', '.form-item-captcha-response', context).forEach(function (wrapper) {

        var prefix = wrapper.querySelector('.field-prefix');
        var input = wrapper.querySelector('input[name="captcha_response"]');

        if (!prefix || !input) {
          return;
        }

        var isHindi =
          document.documentElement.lang === 'hi';

        var helpText = document.createElement('span');

        helpText.id =
          'captcha-a11y-' + Math.floor(Math.random() * 100000);

        helpText.className = 'visually-hidden';

        helpText.textContent = isHindi
          ? 'कृपया कैप्चा मान दर्ज करें ' + prefix.textContent.trim()
          : 'Please enter captcha value ' + prefix.textContent.trim();

        wrapper.appendChild(helpText);

        var describedby =
          input.getAttribute('aria-describedby') || '';

        input.setAttribute(
          'aria-describedby',
          describedby + ' ' + helpText.id
        );

      });

    }
  };

})(jQuery, Drupal, once);

/******************Focus on slider left and right navigation**********************/

/*************** Homepage Slider Accessibility ****************/
(function (Drupal, once) {

  Drupal.behaviors.jnuSliderKeyboardAccessibility = {
    attach: function (context) {

      once('jnu-slider-keyboard', 'body', context).forEach(function () {

        setTimeout(function () {

          var prev = document.querySelector(
            '#views_slideshow_controls_text_previous_home_slideshow_-block_1'
          );

          var next = document.querySelector(
            '#views_slideshow_controls_text_next_home_slideshow_-block_1'
          );

          if (prev && !prev.querySelector('a')) {

            prev.innerHTML =
              '<a href="#" class="jnu-slider-prev" aria-label="Previous Slide" tabindex="0"><i class="fa fa-chevron-left"></i></a>';

          }

          if (next && !next.querySelector('a')) {

            next.innerHTML =
              '<a href="#" class="jnu-slider-next" aria-label="Next Slide" tabindex="0"><i class="fa fa-chevron-right"></i></a>';

          }

        }, 1000);

      });

    }
  };

})(Drupal, once);