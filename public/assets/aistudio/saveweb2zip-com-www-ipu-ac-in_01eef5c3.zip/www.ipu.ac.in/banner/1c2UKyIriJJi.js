/*
============================================================
MPT PHOTO CAROUSEL - ISOLATED JAVASCRIPT
============================================================

- Supports one or many carousels on the same page
- Does not use a global ID
- Does not depend on jQuery
- Does not overwrite window functions
- Automatically initializes after DOM is ready
- Pauses while the mouse is over the carousel
- Restarts after manual navigation
============================================================
*/

(function () {
    "use strict";

    function initMPTCarousel(carousel) {

        if (!carousel || carousel.dataset.mptReady === "1") {
            return;
        }

        const track = carousel.querySelector(".mpt-carousel__track");
        const slides = carousel.querySelectorAll(".mpt-carousel__slide");
        const nextButton = carousel.querySelector(".mpt-carousel__button--next");
        const prevButton = carousel.querySelector(".mpt-carousel__button--prev");

        if (!track || !slides.length || !nextButton || !prevButton) {
            return;
        }

        carousel.dataset.mptReady = "1";

        let currentSlide = 0;
        let timer = null;

        const slideCount = slides.length;
        const interval = 15000;

        function showSlide(number) {

            if (number >= slideCount) {
                currentSlide = 0;
            } else if (number < 0) {
                currentSlide = slideCount - 1;
            } else {
                currentSlide = number;
            }

            track.style.transform =
                "translate3d(-" + (currentSlide * 100) + "%, 0, 0)";
        }

        function startTimer() {
            clearInterval(timer);

            timer = setInterval(function () {
                showSlide(currentSlide + 1);
            }, interval);
        }

        function stopTimer() {
            clearInterval(timer);
            timer = null;
        }

        function restartTimer() {
            startTimer();
        }

        nextButton.addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();

            showSlide(currentSlide + 1);
            restartTimer();
        });

        prevButton.addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();

            showSlide(currentSlide - 1);
            restartTimer();
        });

        carousel.addEventListener("mouseenter", stopTimer);
        carousel.addEventListener("mouseleave", startTimer);

        carousel.addEventListener("focusin", stopTimer);
        carousel.addEventListener("focusout", function () {
            startTimer();
        });

        // Prevent parent page drag/drop or image interaction from
        // interfering with the carousel.
        carousel.querySelectorAll("img").forEach(function (img) {
            img.draggable = false;
        });

        showSlide(0);
        startTimer();
    }

    function initAllMPTCarousels() {
        document.querySelectorAll("[data-mpt-carousel]").forEach(initMPTCarousel);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initAllMPTCarousels);
    } else {
        initAllMPTCarousels();
    }

    // Useful when a page builder (Elementor, Gutenberg, etc.)
    // inserts/replaces content after initial page load.
    if (window.MutationObserver) {
        const observer = new MutationObserver(function (mutations) {
            let shouldInitialize = false;

            mutations.forEach(function (mutation) {
                if (mutation.addedNodes && mutation.addedNodes.length) {
                    shouldInitialize = true;
                }
            });

            if (shouldInitialize) {
                initAllMPTCarousels();
            }
        });

        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });
    }

})();
