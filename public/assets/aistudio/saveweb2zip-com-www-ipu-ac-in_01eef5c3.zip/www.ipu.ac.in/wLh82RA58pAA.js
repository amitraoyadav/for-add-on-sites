function clickAwards() {
  document.getElementById("vc_sir_awards").style.display = "block";
  // document.getElementById("vc_sir_awards").style.transitonDelay = "2s";
  document.getElementById("vc_sir_positions").style.display = "none";
  document.getElementById("vc_sir_publications").style.display = "none";
}

function clickPositions() {
  document.getElementById("vc_sir_awards").style.display = "none";
  document.getElementById("vc_sir_positions").style.display = "block";
  // document.getElementById("vc_sir_positions").style.transitionDelay = "4s";
  document.getElementById("vc_sir_publications").style.display = "none";
}

function clickPublications() {
  document.getElementById("vc_sir_awards").style.display = "none";
  document.getElementById("vc_sir_positions").style.display = "none";
  document.getElementById("vc_sir_publications").style.display = "block";
  // document.getElementById("vc_sir_publications").style.transitionDelay = "2s";
}

function clickrgAwards() {
  document.getElementById("reg_awards").style.display = "block";

  document.getElementById("reg_experience").style.display = "none";
}

function clickexperience() {
  document.getElementById("reg_awards").style.display = "none";
  document.getElementById("reg_experience").style.display = "block";
}
